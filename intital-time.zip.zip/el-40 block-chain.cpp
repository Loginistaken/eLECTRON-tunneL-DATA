#include <iostream>
#include <vector>
#include <ctime>
#include <sstream>
#include <iomanip>
#include <string>
#include <openssl/sha.h>
#include <thread>
#include <chrono>
#include <fstream>
#include <mutex>
#include <unordered_map>
#include <asio.hpp>

struct Transaction {
    std::string sender;
    std::string receiver;
    double amount;
    std::string signature;
};

struct Block {
    int index;
    std::string timestamp;
    std::vector<Transaction> transactions;
    std::string prevHash;
    std::string hash;
    int nonce;
};

std::vector<Block> chain;
std::unordered_map<std::string, double> ledger;
std::mutex chainMutex;

std::string calculateHash(const Block& block);
std::string calculateHash(const std::string& data);
std::string getCurrentTime();
Block createGenesisBlock();
Block createBlock(const std::vector<Transaction>& transactions);
bool isChainValid();
void addBlock(const std::vector<Transaction>& transactions);
std::string mineBlock(Block& block);

std::string calculateHash(const Block& block) {
    std::stringstream ss;
    ss << block.index << block.timestamp << block.prevHash << block.nonce;
    for (const auto& tx : block.transactions) {
        ss << tx.sender << tx.receiver << tx.amount << tx.signature;
    }
    return calculateHash(ss.str());
}

std::string calculateHash(const std::string& data) {
    unsigned char hash[SHA256_DIGEST_LENGTH];
    SHA256(reinterpret_cast<const unsigned char*>(data.c_str()), data.size(), hash);
    std::stringstream ss;
    for (int i = 0; i < SHA256_DIGEST_LENGTH; ++i) {
        ss << std::hex << std::setw(2) << std::setfill('0') << static_cast<int>(hash[i]);
    }
    return ss.str();
}

std::string getCurrentTime() {
    std::time_t now = std::time(nullptr);
    std::tm* timeinfo = std::localtime(&now);
    char buffer[80];
    std::strftime(buffer, sizeof(buffer), "%Y-%m-%d %H:%M:%S", timeinfo);
    return buffer;
}

Block createGenesisBlock() {
    Block genesis;
    genesis.index = 0;
    genesis.timestamp = getCurrentTime();
    genesis.prevHash = "0";
    genesis.nonce = 0;
    genesis.hash = calculateHash(genesis);
    return genesis;
}

bool isValidTransaction(const Transaction& tx, const std::unordered_map<std::string, double>& ledger) {
    if (tx.sender == "Network") return true;
    auto it = ledger.find(tx.sender);
    return it != ledger.end() && it->second >= tx.amount;
}

Block createBlock(const std::vector<Transaction>& transactions) {
    std::lock_guard<std::mutex> lock(chainMutex);
    Block newBlock;
    newBlock.index = chain.size();
    newBlock.timestamp = getCurrentTime();
    newBlock.transactions = transactions;
    newBlock.prevHash = chain.back().hash;
    newBlock.nonce = 0;
    newBlock.hash = mineBlock(newBlock);
    return newBlock;
}

bool isChainValid() {
    for (size_t i = 1; i < chain.size(); ++i) {
        const Block& current = chain[i];
        const Block& previous = chain[i - 1];

        if (current.hash != calculateHash(current)) return false;
        if (current.prevHash != previous.hash) return false;
    }
    return true;
}

void addBlock(const std::vector<Transaction>& transactions) {
    std::vector<Transaction> blockTxs;
    for (const auto& tx : transactions) {
        if (isValidTransaction(tx, ledger)) {
            blockTxs.push_back(tx);
        } else {
            std::cout << "[!] Invalid transaction from " << tx.sender << ": insufficient balance\n";
            return;
        }
    }
    Block newBlock = createBlock(blockTxs);
    std::lock_guard<std::mutex> lock(chainMutex);
    chain.push_back(newBlock);
    for (const auto& tx : blockTxs) {
        ledger[tx.sender] -= tx.amount;
        ledger[tx.receiver] += tx.amount;
    }
    std::cout << "Block added: " << newBlock.hash << "\n";
}

std::string mineBlock(Block& block) {
    std::string hash;
    do {
        ++block.nonce;
        hash = calculateHash(block);
    } while (hash.substr(0, 4) != "0000");
    return hash;
}

void exportToJSON(const std::string& filename) {
    std::lock_guard<std::mutex> lock(chainMutex);
    std::ofstream outFile(filename);
    outFile << "[\n";
    for (size_t i = 0; i < chain.size(); ++i) {
        const Block& b = chain[i];
        outFile << "  {\n"
                << "    \"index\": " << b.index << ",\n"
                << "    \"timestamp\": \"" << b.timestamp << "\",\n"
                << "    \"prevHash\": \"" << b.prevHash << "\",\n"
                << "    \"hash\": \"" << b.hash << "\",\n"
                << "    \"nonce\": " << b.nonce << ",\n"
                << "    \"transactions\": [\n";
        for (size_t j = 0; j < b.transactions.size(); ++j) {
            const auto& tx = b.transactions[j];
            outFile << "      {\"from\": \"" << tx.sender
                    << "\", \"to\": \"" << tx.receiver
                    << "\", \"amount\": " << tx.amount
                    << ", \"signature\": \"" << tx.signature << "\"}";
            if (j + 1 < b.transactions.size()) outFile << ",";
            outFile << "\n";
        }
        outFile << "    ]\n  }";
        if (i + 1 < chain.size()) outFile << ",";
        outFile << "\n";
    }
    outFile << "]\n";
    outFile.close();
    std::cout << "[✓] Blockchain exported to " << filename << "\n";
}

void showLedgerBalances(const std::unordered_map<std::string, double>& ledger) {
    std::cout << "\n--- Ledger Balances ---\n";
    for (const auto& [address, balance] : ledger) {
        std::cout << address << ": " << balance << " ELX\n";
    }
}

void pushToAPI(const std::string& url) {
    std::cout << "[→] Pushing blockchain data to external API at: " << url << "\n";
    // Placeholder: Use libcurl or C++ HTTP client for real requests
}

int main() {
    chain.push_back(createGenesisBlock());

    Transaction tx1 = {"Network", "Alice", 100.0, "sig1"};
    Transaction tx2 = {"Alice", "Bob", 50.0, "sig2"};

    ledger["Network"] = 1e12;
    ledger["Alice"] = 0;
    ledger["Bob"] = 0;

    addBlock({tx1});
    addBlock({tx2});

    exportToJSON("blockchain.json");
    showLedgerBalances(ledger);
    pushToAPI("https://example.com/api/blockchain");

    return 0;
}
